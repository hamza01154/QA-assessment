
// login.spec.js
const puppeteer = require('puppeteer');
const { loginUrl, credentials, selectors } = require('./helpers');

(async () => {
  const browser = await puppeteer.launch({ headless: false });
  const page = await browser.newPage();
  await page.goto(loginUrl);

  // 1-Enter credentials
  await page.type(selectors.usernameInput, credentials.username);
  await page.type(selectors.passwordInput, credentials.password);

  //  2-Click Login
  await page.click(selectors.loginButton);
  await page.waitForSelector(selectors.successMessage);

  //  3-Verify success message
  const successText = await page.$eval(selectors.successMessage, el => el.textContent);
  console.log("Login Success Message:", successText);

  //  4- Navigate to another page
  await page.goto('https://the-internet.herokuapp.com/secure');

  // 5-Click Logout
  await page.click(selectors.logoutButton);
  await page.waitForSelector(selectors.loginButton);

  console.log("Successfully logged out and redirected.");

  await browser.close();
})();
